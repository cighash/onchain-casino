pub const MASTER_SEED: &str = "master";
pub const LOTTERY_SEED: &str = "lottery";
pub const TICKET_SEED: &str = "ticket";